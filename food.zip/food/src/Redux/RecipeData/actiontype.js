



export const GET_getdata_REQUEST="GET_getdata_REQUEST"
export const GET_getdata_SUCCESS="GET_getdata_SUCCESS"
export const GET_getdata_FAILURE="GET_getdata_FAILURE"

export const GET_getsingledata_REQUEST="GET_getsingledata_REQUEST"
export const GET_getsingledata_SUCCESS="GET_getsingledata_SUCCESS"
export const GET_getsingledata_FAILURE="GET_getsingledata_FAILURE"
